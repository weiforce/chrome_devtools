export declare const storeGeneratedResults: (file: string, content: string) => void;
export declare const percentile: (values: number[], position: number) => number;
export declare const mean: (values: number[]) => number;
