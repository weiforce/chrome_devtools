export declare const enum TextColor {
    DIM = "DIM",
    GREEN = "GREEN",
    RED = "RED",
    MAGENTA = "MAGENTA",
    CYAN = "CYAN"
}
export declare function color(msg: string, color: TextColor): string;
