function shown1() {
  shown2();
}

function shown2() {
  shown3();
}

function shown3() {
  document.doesNotExist();
}
