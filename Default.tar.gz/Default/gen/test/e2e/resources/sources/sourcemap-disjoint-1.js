(() => {
function test() {
    return console.log(window.location);
}
})();
//# sourceMappingURL=sourcemap-disjoint-1.map
