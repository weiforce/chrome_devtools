function simple(a) {
  let x = a + 1;
  return x;
}
