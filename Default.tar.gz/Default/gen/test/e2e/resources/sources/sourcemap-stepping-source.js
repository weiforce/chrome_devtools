function add(a, b) { return a + b; }

function multiline() {
    const x = add(1, 2);
    const y = add(3, 4);
    const z = add(x, y);

    console.log(z);
}

function singleline() {
    const x = add(1, 2);
    const y = add(3, 4);
    const z = add(x, y);

    console.log(z);
}
