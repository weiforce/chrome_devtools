function foo(o){console.log(o);for(let o=0;o<2e3;o++){console.log(o)}}
//# sourceMappingURL=sourcemap-scopes-minified-compiled.js.map
