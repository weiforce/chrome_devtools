int global = 7;

int Main() {
  return global;
}
