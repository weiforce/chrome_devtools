function f2() {
  console.log('f2');
}
