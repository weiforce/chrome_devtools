function f1() {
  console.log('f1');
}
