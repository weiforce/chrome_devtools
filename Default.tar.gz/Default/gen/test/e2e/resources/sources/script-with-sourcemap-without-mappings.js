console.log("hello");
//# sourceMappingURL=sourcemap-without-mappings.map
