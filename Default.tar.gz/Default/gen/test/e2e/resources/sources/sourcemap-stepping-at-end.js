function inner() {
  debugger;
}
