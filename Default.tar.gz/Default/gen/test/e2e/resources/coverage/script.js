let x = 0;
function foo() {
  x = x + 1;
}
