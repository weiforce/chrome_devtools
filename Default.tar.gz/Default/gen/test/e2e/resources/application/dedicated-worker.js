onmessage = function(e) {
  postMessage('Worker posting message.');
}
