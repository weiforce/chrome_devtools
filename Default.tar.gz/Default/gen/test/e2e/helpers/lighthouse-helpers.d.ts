export declare function navigateToLighthouseTab(path: string): Promise<void>;
export declare function isGenerateReportButtonDisabled(): Promise<boolean>;
