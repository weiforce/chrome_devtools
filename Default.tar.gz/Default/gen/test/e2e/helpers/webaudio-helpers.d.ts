export declare function waitForTheWebAudioPanelToLoad(): Promise<void>;
export declare function navigateToSiteWithAudioContexts(): Promise<void>;
export declare function waitForWebAudioContent(): Promise<void>;
