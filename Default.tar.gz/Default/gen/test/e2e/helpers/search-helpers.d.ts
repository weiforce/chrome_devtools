import type * as puppeteer from 'puppeteer';
export declare function triggerFindDialog(frontend: puppeteer.Page): Promise<void>;
