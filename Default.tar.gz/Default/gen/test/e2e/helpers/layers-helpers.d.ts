export declare const LAYERS_TAB_SELECTOR = "#tab-layers";
export declare function getCurrentUrl(): Promise<string | null>;
