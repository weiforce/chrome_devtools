export declare function clickStylePropertyEditorButton(title: string, editorElement: 'devtools-grid-editor' | 'devtools-flexbox-editor'): Promise<void>;
export declare function clickPropertyButton(selector: string): Promise<void>;
