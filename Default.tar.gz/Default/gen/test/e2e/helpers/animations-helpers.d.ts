export declare function waitForAnimationsPanelToLoad(): Promise<void>;
export declare function navigateToSiteWithAnimation(): Promise<void>;
export declare function waitForAnimationContent(): Promise<void>;
